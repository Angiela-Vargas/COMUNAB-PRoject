# Material-3-Carousel-Android
This repository contains code of implementation of material 3 carousel view in Android Studio using Java.
Tutorial: https://youtu.be/Nld8bmj2BQE
