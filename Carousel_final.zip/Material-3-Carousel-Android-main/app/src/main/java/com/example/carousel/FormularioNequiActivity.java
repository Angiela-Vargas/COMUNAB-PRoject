package com.example.carousel;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class FormularioNequiActivity extends AppCompatActivity {

    private EditText nombreEditText;
    private EditText programaEditText;
    private EditText actividadEditText;
    private EditText horasEditText;
    private EditText numeroEditText;
    private EditText valorEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.formulario_nequi);

        nombreEditText = findViewById(R.id.c_nombre_usuario);
        programaEditText = findViewById(R.id.c_programa_usuario);
        actividadEditText = findViewById(R.id.c_actividad_usuario);
        horasEditText = findViewById(R.id.c_horas_usuario);
        numeroEditText = findViewById(R.id.c_numero_usuario);
        valorEditText = findViewById(R.id.c_valor_usuario);

        // Obtén la referencia del botón "Volver"
        Button buttonVolver = findViewById(R.id.buttonVolver);
        Button buttonComprar = findViewById(R.id.button6);
        Button buttonVerCompras = findViewById(R.id.buttonVerCompras);

        // Configura el OnClickListener para el botón "Volver"
        buttonVolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Finaliza esta actividad y regresa a la MainActivity
                finish();
            }
        });

        // Configura el OnClickListener para el botón "Comprar"
        buttonComprar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (camposFormularioLlenos()) {
                    guardarDatos();
                } else {
                    mostrarMensajeError("Por favor complete todos los campos antes de comprar.");
                }
            }
        });

        // Configura el OnClickListener para el botón "Ver mis compras"
        buttonVerCompras.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mostrarCompras();
            }
        });
    }

    private void guardarDatos() {
        SharedPreferences sharedPreferences = getSharedPreferences("DatosFormulario", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("nombre", nombreEditText.getText().toString());
        editor.putString("programa", programaEditText.getText().toString());
        editor.putString("actividad", actividadEditText.getText().toString());
        editor.putString("horas", horasEditText.getText().toString());
        editor.putString("numero", numeroEditText.getText().toString());
        editor.putString("valor", valorEditText.getText().toString());
        editor.apply();
    }

    private boolean camposFormularioLlenos() {
        return !nombreEditText.getText().toString().isEmpty() &&
                !programaEditText.getText().toString().isEmpty() &&
                !actividadEditText.getText().toString().isEmpty() &&
                !horasEditText.getText().toString().isEmpty() &&
                !numeroEditText.getText().toString().isEmpty() &&
                !valorEditText.getText().toString().isEmpty();
    }

    private void mostrarCompras() {
        SharedPreferences sharedPreferences = getSharedPreferences("DatosFormulario", MODE_PRIVATE);
        String nombre = sharedPreferences.getString("nombre", "");
        String programa = sharedPreferences.getString("programa", "");
        String actividad = sharedPreferences.getString("actividad", "");
        String horas = sharedPreferences.getString("horas", "");
        String numero = sharedPreferences.getString("numero", "");
        String valor = sharedPreferences.getString("valor", "");

        // Crear una vista personalizada para mostrar los datos
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_compras, null);

        TextView nombreTextView = dialogView.findViewById(R.id.nombreTextView);
        TextView programaTextView = dialogView.findViewById(R.id.programaTextView);
        TextView actividadTextView = dialogView.findViewById(R.id.actividadTextView);
        TextView horasTextView = dialogView.findViewById(R.id.horasTextView);
        TextView numeroTextView = dialogView.findViewById(R.id.numeroTextView);
        TextView valorTextView = dialogView.findViewById(R.id.valorTextView);

        nombreTextView.setText(nombre);
        programaTextView.setText(programa);
        actividadTextView.setText(actividad);
        horasTextView.setText(horas);
        numeroTextView.setText(numero);
        valorTextView.setText(valor);

        // Construir el diálogo y mostrarlo
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(dialogView);
        builder.setTitle("Mis Compras");
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Cierra el diálogo
                dialog.dismiss();
            }
        });
        builder.create().show();
    }

    private void mostrarMensajeError(String mensaje) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Error");
        builder.setMessage(mensaje);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Cierra el diálogo
                dialog.dismiss();
            }
        });
        builder.create().show();
    }
}