package com.example.carousel;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class ConsultaHorasActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.consulta_horas);

        Button btnpublicacion = findViewById(R.id.buttonpubli);
        btnpublicacion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ConsultaHorasActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        Button button8 = findViewById(R.id.buttonA);
        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mensaje = "Horas disponibles: 25 \nValor por hora: 8000$";

                AlertDialog.Builder builder = new AlertDialog.Builder(ConsultaHorasActivity.this);
                builder.setTitle("Horas libres Nequi");
                builder.setMessage(mensaje);

                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                builder.setNeutralButton("Comprar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(ConsultaHorasActivity.this, FormularioNequiActivity.class);
                        startActivity(intent);
                    }
                });

                // Crear y mostrar el diálogo
                AlertDialog dialog = builder.create();
                dialog.show();

                // Ajustar el tamaño de la ventana del diálogo
                WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
                layoutParams.copyFrom(dialog.getWindow().getAttributes());
                layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
                layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
                dialog.getWindow().setAttributes(layoutParams);
            }
        });

        Button button9 = findViewById(R.id.buttonB);
        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mensaje = "Horas disponibles: 10 \nValor por hora: 8000$";

                AlertDialog.Builder builder = new AlertDialog.Builder(ConsultaHorasActivity.this);
                builder.setTitle("Horas libres Billetera");
                builder.setMessage(mensaje);

                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                builder.setNeutralButton("Comprar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(ConsultaHorasActivity.this, FormularioBilleteraActivity.class);
                        startActivity(intent);
                    }
                });

                // Crear y mostrar el diálogo
                AlertDialog dialog = builder.create();
                dialog.show();

                // Ajustar el tamaño de la ventana del diálogo
                WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
                layoutParams.copyFrom(dialog.getWindow().getAttributes());
                layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
                layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
                dialog.getWindow().setAttributes(layoutParams);
            }
        });

        Button button10 = findViewById(R.id.buttonC);
        button10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mensaje = "Promedio: 15 horas \nSemestre: 3 \nMes: Septiembre \nAño: 2022";

                AlertDialog.Builder builder = new AlertDialog.Builder(ConsultaHorasActivity.this);
                builder.setTitle("Promedio Horas libres");
                builder.setMessage(mensaje);

                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                // Crear y mostrar el diálogo
                AlertDialog dialog = builder.create();
                dialog.show();

                // Ajustar el tamaño de la ventana del diálogo
                WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
                layoutParams.copyFrom(dialog.getWindow().getAttributes());
                layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
                layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
                dialog.getWindow().setAttributes(layoutParams);
            }
        });

        Button button11 = findViewById(R.id.buttonD);
        button11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mensaje = "Horas Certificadas: 25 horas";

                AlertDialog.Builder builder = new AlertDialog.Builder(ConsultaHorasActivity.this);
                builder.setTitle("Horas Libres Actualmente");
                builder.setMessage(mensaje);

                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                // Crear y mostrar el diálogo
                AlertDialog dialog = builder.create();
                dialog.show();

                // Ajustar el tamaño de la ventana del diálogo
                WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
                layoutParams.copyFrom(dialog.getWindow().getAttributes());
                layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
                layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
                dialog.getWindow().setAttributes(layoutParams);
            }
        });

        Button button12 = findViewById(R.id.buttonE);
        button12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mensaje = "Horas Libres totales: 96 horas \nHoras Libres actuales: 25 \nHoras Libres faltantes: 71";

                AlertDialog.Builder builder = new AlertDialog.Builder(ConsultaHorasActivity.this);
                builder.setTitle("Horas Libres Faltantes");
                builder.setMessage(mensaje);

                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                // Crear y mostrar el diálogo
                AlertDialog dialog = builder.create();
                dialog.show();

                // Ajustar el tamaño de la ventana del diálogo
                WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
                layoutParams.copyFrom(dialog.getWindow().getAttributes());
                layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
                layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
                dialog.getWindow().setAttributes(layoutParams);
            }
        });

        Button btnRegistrar = findViewById(R.id.button_registrar);
        btnRegistrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ConsultaHorasActivity.this, RegistrarHorasLibres.class);
                startActivity(intent);
            }
        });

        Button btnAsistir = findViewById(R.id.button_asistir);
        btnAsistir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ConsultaHorasActivity.this, AsistirHorasLibres.class);
                startActivity(intent);
            }
        });

        Button btnCharla = findViewById(R.id.btn_charla);
        btnCharla.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ConsultaHorasActivity.this, ParticiparCharlasHorasLibres.class);
                startActivity(intent);
            }
        });

        Button btnColaborar = findViewById(R.id.btn_colaborar);
        btnColaborar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ConsultaHorasActivity.this, ColaborarEventoHorasLibres.class);
                startActivity(intent);
            }
        });

        Button btnProponer = findViewById(R.id.btn_proponer);
        btnProponer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ConsultaHorasActivity.this, ProponerActividadHorasLibres.class);
                startActivity(intent);
            }
        });
    }

    public void showPopupMenu(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Selecciona una opción");
        builder.setItems(R.array.options_array, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case 0: // Opción 1 seleccionada
                        openWebPage("https://unab.edu.co/");
                        break;
                    case 1: // Opción 2 seleccionada
                        openWebPage("https://unabvirtual.unab.edu.co/");
                        break;
                    case 2: // Opción 3 seleccionada
                        openWebPage("https://mail.google.com/");
                        break;
                    case 3: // Opción 4 seleccionada
                        openWebPage("https://tema.unab.edu.co/");
                        break;
                    case 4: // Opción 8 seleccionada
                        openWebPage("https://unab.instructure.com/login");
                        break;
                    case 5: // Opción 5 seleccionada
                        openWebPage("https://cosmos.unab.edu.co/");
                        break;
                    case 6: // Opción 6 seleccionada
                        openWebPage("https://unab.edu.co/sistema-de-bibliotecas-unab/");
                        break;
                    case 7: // Opción 7 seleccionada
                        openWebPage("https://bienestar.unab.edu.co/");
                        break;

                }
            }
        });
        builder.show();
    }

    private void openWebPage(String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);
    }
}