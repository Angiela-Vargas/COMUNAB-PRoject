package com.example.carousel;

import android.app.ActivityOptions;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class ComunidadUnabActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.comunidad_unab);

        Button btnComunidad = findViewById(R.id.button6);
        btnComunidad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://unab.edu.co/la-universidad/";

                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(intent);
            }
        });

        Button btnVolver = findViewById(R.id.btn_volver);
        btnVolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Crea un Intent para regresar a MainActivity
                Intent intent = new Intent(ComunidadUnabActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        Button button8 = findViewById(R.id.button8);
        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mensaje = "Campus el jardin : 5152 Estudiantes \nCampus el Bosque: 2236 Estudiantes \nCampus Rafael Ardila: 452 Estudiantes";

                AlertDialog.Builder builder = new AlertDialog.Builder(ComunidadUnabActivity.this);
                builder.setTitle("Estudiantes por Campus");
                builder.setMessage(mensaje);

                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                // Crear y mostrar el diálogo
                AlertDialog dialog = builder.create();
                dialog.show();

                // Ajustar el tamaño de la ventana del diálogo
                WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
                layoutParams.copyFrom(dialog.getWindow().getAttributes());
                layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
                layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
                dialog.getWindow().setAttributes(layoutParams);
            }
        });


        Button button9 = findViewById(R.id.button9);
        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mensaje = "UNAB TEC: 1290\nFacultad Ciencias de la Salud: 1537\nFacultad Juridica: 705\nFacultad de Humanidades: 1139\nFacultad de Ciencias Contables: 946\nFacultad de Ingenieria: 1202";

                AlertDialog.Builder builder = new AlertDialog.Builder(ComunidadUnabActivity.this);
                builder.setTitle("Estudiantes Por Facultad");
                builder.setMessage(mensaje);

                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                // Mostrar el diálogo
                builder.show();
            }
        });
        Button button10 = findViewById(R.id.button10);
        button10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mensaje = "Pregrado (Presencial) : 5049\nTecnologias (Virtual y Dual): 964\nPosgrados (Presencial): 940\nPregrados (Virtual): 783\nPregrado Presencial (Convenio con Otras Ciudades): 710\nPosgrados (Virtual): 527\nTecnologias (Presencial: 217";


                AlertDialog.Builder builder = new AlertDialog.Builder(ComunidadUnabActivity.this);
                builder.setTitle("Estudiantes por Grado Educativo");
                builder.setMessage(mensaje);

                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                // Mostrar el diálogo
                builder.show();
            }
        });
        Button button11 = findViewById(R.id.button11);
        button11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mensaje = "Bucaramanga: 2722 Estudiantes\nPiedecuesta:983 Estudiantes\nFloridaBlanca: 1532 Estudiantes\nCucuta: 872 Estudiantes\nBarrancabermeja:820 Estudiantes\nBarichara:2 Estudiantes";

                AlertDialog.Builder builder = new AlertDialog.Builder(ComunidadUnabActivity.this);
                builder.setTitle("Estudiantes Por Ciudad");
                builder.setMessage(mensaje);

                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                // Mostrar el diálogo
                builder.show();
            }
        });
        Button button12 = findViewById(R.id.button12);
        button12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mensaje = "Profesores:762\nClasificados en :\nTiempo Completo:304 Docentes \nMedio Tiempo:102 Docentes\nHora Catedra:356 Docentes";

                AlertDialog.Builder builder = new AlertDialog.Builder(ComunidadUnabActivity.this);
                builder.setTitle("Cantidad de Profesores");
                builder.setMessage(mensaje);

                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                // Mostrar el diálogo
                builder.show();
            }
        });
        Button button13 = findViewById(R.id.button13);
        button13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mensaje = "Durante el 2024 la UNAB alcanzo los 8062 Estudiantes";

                AlertDialog.Builder builder = new AlertDialog.Builder(ComunidadUnabActivity.this);
                builder.setTitle("Cantidad de Estudiantes");
                builder.setMessage(mensaje);

                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                // Mostrar el diálogo
                builder.show();
            }
        });
        Button button14 = findViewById(R.id.button14);
        button14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mensaje = "Administrativos: 184 administrativos";

                AlertDialog.Builder builder = new AlertDialog.Builder(ComunidadUnabActivity.this);
                builder.setTitle("Cantidad Administrativos");
                builder.setMessage(mensaje);

                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                // Mostrar el diálogo
                builder.show();
            }
        });
        RecyclerView recyclerView3 = findViewById(R.id.recycler3);
        ArrayList<String> arrayList3 = new ArrayList<>();


        arrayList3.add("https://www.unired.edu.co/images/instituciones/UNAB/2017/junio/unab.jpg");
        arrayList3.add("https://unab.edu.co/wp-content/uploads/2023/11/Estudiantes-de-Ingenieria-van-a-Brasil.png");
        arrayList3.add("https://unab.edu.co/wp-content/uploads/2022/01/1.-Vista-area-CSU.jpg");
        arrayList3.add("https://unab.edu.co/wp-content/uploads/2022/11/factor-10.jpeg");
        arrayList3.add("https://unab.edu.co/wp-content/uploads/2024/02/torniquetes-csu-1.jpg");
        arrayList3.add("https://unab.edu.co/wp-content/uploads/2022/08/Breves_Equipo_Ingeneria-de-Sistemas_4.jpg");


        ImageAdapter adapter = new ImageAdapter(this, arrayList3);
        recyclerView3.setAdapter(adapter);

        adapter.setOnItemClickListener(new ImageAdapter.OnItemClickListener() {
            @Override
            public void onClick(ImageView imageView, String path) {
                startActivity(new Intent(ComunidadUnabActivity.this, ImageViewActivity.class).putExtra("image", path), ActivityOptions.makeSceneTransitionAnimation(ComunidadUnabActivity.this, imageView, "image").toBundle());
            }
        });
        ImageView imageView = findViewById(R.id.imageView);}

    public void showPopupMenu(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Selecciona una opción");
        builder.setItems(R.array.options_array, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case 0: // Opción 1 seleccionada
                        openWebPage("https://unab.edu.co/");
                        break;
                    case 1: // Opción 2 seleccionada
                        openWebPage("https://unabvirtual.unab.edu.co/");
                        break;
                    case 2: // Opción 3 seleccionada
                        openWebPage("https://mail.google.com/");
                        break;
                    case 3: // Opción 4 seleccionada
                        openWebPage("https://tema.unab.edu.co/");
                        break;
                    case 4: // Opción 8 seleccionada
                        openWebPage("https://unab.instructure.com/login");
                        break;
                    case 5: // Opción 5 seleccionada
                        openWebPage("https://cosmos.unab.edu.co/");
                        break;
                    case 6: // Opción 6 seleccionada
                        openWebPage("https://unab.edu.co/sistema-de-bibliotecas-unab/");
                        break;
                    case 7: // Opción 7 seleccionada
                        openWebPage("https://bienestar.unab.edu.co/");
                        break;

                }
            }
        });
        builder.show();
    }

    private void openWebPage(String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);
    }
}