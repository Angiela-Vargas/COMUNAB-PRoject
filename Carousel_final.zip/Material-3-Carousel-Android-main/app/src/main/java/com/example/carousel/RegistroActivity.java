package com.example.carousel;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegistroActivity extends AppCompatActivity {

    private EditText usuarioEditText;
    private EditText contraseñaEditText;
    private EditText correoEditText;
    private Button registrarButton;
    private Button volverButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registro_app);

        usuarioEditText = findViewById(R.id.registro_usuario);
        contraseñaEditText = findViewById(R.id.registro_contraseña);
        correoEditText = findViewById(R.id.registro_correo);
        registrarButton = findViewById(R.id.boton_registrar);
        volverButton = findViewById(R.id.boton_vol_c);

        registrarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String usuario = usuarioEditText.getText().toString();
                String contraseña = contraseñaEditText.getText().toString();
                String correo = correoEditText.getText().toString();

                if (!usuario.isEmpty() && !contraseña.isEmpty() && !correo.isEmpty()) {
                    if (!usuarioYaRegistrado(usuario)) {
                        guardarUsuario(usuario, contraseña, correo);
                        Toast.makeText(RegistroActivity.this, "Registro exitoso", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(RegistroActivity.this, LoginActivity.class);
                        startActivity(intent);
                        finish(); // Cierra la actividad de registro y vuelve a la actividad de login
                    } else {
                        Toast.makeText(RegistroActivity.this, "Este usuario ya se encuentra registrado", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(RegistroActivity.this, "Por favor, llene todos los campos", Toast.LENGTH_SHORT).show();
                }
            }
        });

        volverButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Volver al login
                Intent intent = new Intent(RegistroActivity.this, LoginActivity.class);
                startActivity(intent);
                finish(); // Cerrar esta actividad para evitar volver a ella con el botón de retroceso
            }
        });
    }

    private boolean usuarioYaRegistrado(String usuario) {
        SharedPreferences sharedPreferences = getSharedPreferences("Usuarios", MODE_PRIVATE);
        String usuarioRegistrado = sharedPreferences.getString("usuario", "");
        return usuario.equals(usuarioRegistrado);
    }

    private void guardarUsuario(String usuario, String contraseña, String correo) {
        SharedPreferences sharedPreferences = getSharedPreferences("Usuarios", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("usuario", usuario);
        editor.putString("contraseña", contraseña);
        editor.putString("correo", correo);
        editor.apply();
    }
}