package com.example.carousel;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ActivityOptions;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        configureMainLayout();
    }

    private void configureMainLayout() {
        Button btnComunidad = findViewById(R.id.button4);
        btnComunidad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ComunidadUnabActivity.class);
                startActivity(intent);
            }
        });

        Button buttonCumplimientoCurricular = findViewById(R.id.button_cumplimiento_curricular);
        buttonCumplimientoCurricular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CumplimientoCurricularActivity.class);
                startActivity(intent);
            }
        });

        Button buttonConsultaHoras = findViewById(R.id.button_horas_libres);
        buttonConsultaHoras.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ConsultaHorasActivity.class);
                startActivity(intent);
            }
        });

        RecyclerView recyclerView1 = findViewById(R.id.recycler2);
        RecyclerView recyclerView2 = findViewById(R.id.recycler);
        ArrayList<String> arrayList = new ArrayList<>();
        ArrayList<String> arrayList2 = new ArrayList<>();

        arrayList.add("https://unab.edu.co/wp-content/uploads/2024/05/Afiche-Festival-de-Cine-Europeo-731x1024.jpeg");
        arrayList.add("https://unab.edu.co/wp-content/uploads/2024/05/Analisis-inclusion-financiera-1024x1024.png");
        arrayList.add("https://unab.edu.co/wp-content/uploads/2024/05/Trasnformacion-Social-LEI-2-1.jpg");
        arrayList.add("https://unab.edu.co/wp-content/uploads/2024/05/Congreso-Neurociencia-Educativa-1024x1024.jpeg");
        arrayList.add("https://unab.edu.co/wp-content/uploads/2024/04/Grados-Universidad-UNAB-scaled.jpg");
        arrayList.add("https://unab.edu.co/wp-content/uploads/2024/05/imagen-unabfest2024.jpg");

        arrayList2.add("https://unab.edu.co/wp-content/uploads/2024/05/Festival-1-1024x1024.png");
        arrayList2.add("https://unab.edu.co/wp-content/uploads/2024/05/webinar_1.png");
        arrayList2.add("https://unab.edu.co/wp-content/uploads/2024/04/Biblioteca-24-horas.jpeg");
        arrayList2.add("https://pbs.twimg.com/media/GMA1iaIXgAAx1-Y.jpg");
        arrayList2.add("https://unab.edu.co/wp-content/uploads/2022/01/csu-3-1080x675.jpg");
        arrayList2.add("https://www.unab.edu.co/sites/default/files/PANTALLA-DIGITAL%20%282%29.png");

        ImageAdapter adapter = new ImageAdapter(MainActivity.this, arrayList);
        recyclerView1.setAdapter(adapter);

        ImageAdapter adapter2 = new ImageAdapter(MainActivity.this, arrayList2);
        recyclerView2.setAdapter(adapter2);

        adapter.setOnItemClickListener(new ImageAdapter.OnItemClickListener() {
            @Override
            public void onClick(ImageView imageView, String path) {
                if (path.equals(arrayList.get(0))) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://unab.edu.co/unab-se-une-a-los-30-anos-del-festival-de-cine-europeo/"));
                    startActivity(intent);
                } else if (path.equals(arrayList.get(1))) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://unab.edu.co/inclusion-financiera-en-santander-el-90-9-de-la-poblacion-tiene-acceso-a-servicios-financieros/"));
                    startActivity(intent);
                } else if (path.equals(arrayList.get(2))) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://unab.edu.co/transformacion-social-unab-crece-en-bucaramanga/"));
                    startActivity(intent);
                } else if (path.equals(arrayList.get(3))) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://unab.edu.co/congreso-de-neurociencia-educativa-sera-en-la-unab/"));
                    startActivity(intent);
                } else if (path.equals(arrayList.get(5))) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://unab.edu.co/unab-fest-2024-llega-la-segunda-edicion-del-festival/"));
                    startActivity(intent);
                } else if (path.equals(arrayList.get(4))) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://unab.edu.co/universidad-unab-prepara-su-primera-jornada-de-grados-de-2024/"));
                    startActivity(intent);
                } else {
                    startActivity(new Intent(MainActivity.this, ImageViewActivity.class).putExtra("image", path), ActivityOptions.makeSceneTransitionAnimation(MainActivity.this, imageView, "image").toBundle());
                }
            }
        });

        adapter2.setOnItemClickListener(new ImageAdapter.OnItemClickListener() {
            public void onClick(ImageView imageView, String path) {
                if (path.equals(arrayList2.get(0))) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://unab.edu.co/festival-oriental-en-el-hostal-unab/"));
                    startActivity(intent);
                } else if (path.equals(arrayList2.get(1))) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://unab.edu.co/cual-es-el-exito-de-la-formacion-tecnica-laboral/"));
                    startActivity(intent);
                } else if (path.equals(arrayList2.get(2))) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://unab.edu.co/vuelve-el-servicio-de-biblioteca-24-horas/"));
                    startActivity(intent);
                } else if (path.equals(arrayList2.get(3))) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://unab.edu.co/conozca-el-programa-de-auditoria-del-2024/"));
                    startActivity(intent);
                } else if (path.equals(arrayList2.get(4))) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://unab.edu.co/juegos-deportivos-unab-2024/"));
                    startActivity(intent);
                } else if (path.equals(arrayList2.get(5))) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://unab.edu.co/asi-vamos-a-conmemorar-el-dia-internacional-de-la-mujer-en-la-unab/"));
                    startActivity(intent);
                } else {
                    startActivity(new Intent(MainActivity.this, ImageViewActivity.class).putExtra("image", path), ActivityOptions.makeSceneTransitionAnimation(MainActivity.this, imageView, "image").toBundle());
                }
            }
        });

        ImageView imageView = findViewById(R.id.imageView);
    }

    public void showPopupMenu(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Selecciona una opción");
        builder.setItems(R.array.options_array, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case 0: // Opción 1 seleccionada
                        openWebPage("https://unab.edu.co/");
                        break;
                    case 1: // Opción 2 seleccionada
                        openWebPage("https://unabvirtual.unab.edu.co/");
                        break;
                    case 2: // Opción 3 seleccionada
                        openWebPage("https://mail.google.com/");
                        break;
                    case 3: // Opción 4 seleccionada
                        openWebPage("https://tema.unab.edu.co/");
                        break;
                    case 4: // Opción 8 seleccionada
                        openWebPage("https://unab.instructure.com/login");
                        break;
                    case 5: // Opción 5 seleccionada
                        openWebPage("https://cosmos.unab.edu.co/");
                        break;
                    case 6: // Opción 6 seleccionada
                        openWebPage("https://unab.edu.co/sistema-de-bibliotecas-unab/");
                        break;
                    case 7: // Opción 7 seleccionada
                        openWebPage("https://bienestar.unab.edu.co/");
                        break;
                }
            }
        });
        builder.show();
    }

    private void openWebPage(String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);
    }
}