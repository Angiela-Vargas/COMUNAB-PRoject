package com.example.carousel;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;


import androidx.appcompat.app.AppCompatActivity;

public class CumplimientoCurricularActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cumplimiento_curricular);

        Button btnpublicacion = findViewById(R.id.buttonpubli);
        btnpublicacion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CumplimientoCurricularActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        Button buttonConsultaHoras = findViewById(R.id.button_horas_libres);
        buttonConsultaHoras.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CumplimientoCurricularActivity.this, ConsultaHorasActivity.class);
                startActivity(intent);
            }
        });

        Button button8 = findViewById(R.id.buttonA);
        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mensaje = "Expresion: 4.7 \nÁlgebra Lineal: 5.0 \nCáculo Diferencial: 4.8 \nProgramación de Computadores: 4.8 \nSeminario 1: 4.8";

                AlertDialog.Builder builder = new AlertDialog.Builder(CumplimientoCurricularActivity.this);
                builder.setTitle("Calificaciones Semestre 1");
                builder.setMessage(mensaje);

                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                // Crear y mostrar el diálogo
                AlertDialog dialog = builder.create();
                dialog.show();

                // Ajustar el tamaño de la ventana del diálogo
                WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
                layoutParams.copyFrom(dialog.getWindow().getAttributes());
                layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
                layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
                dialog.getWindow().setAttributes(layoutParams);
            }
        });

        Button button9 = findViewById(R.id.buttonB);
        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mensaje = "Calculo Integral: 4.7 \nDiseño de Interfaces: 5.0 \nIdentidad: 4.8 \nLaboratorio Mecanica: A \nMecanica: 4.8\nProgramacion de Computadoras: 4.8";

                AlertDialog.Builder builder = new AlertDialog.Builder(CumplimientoCurricularActivity.this);
                builder.setTitle("Calificaciones Semestre 2");
                builder.setMessage(mensaje);

                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                // Crear y mostrar el diálogo
                AlertDialog dialog = builder.create();
                dialog.show();

                // Ajustar el tamaño de la ventana del diálogo
                WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
                layoutParams.copyFrom(dialog.getWindow().getAttributes());
                layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
                layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
                dialog.getWindow().setAttributes(layoutParams);
            }
        });

        Button button10 = findViewById(R.id.buttonC);
        button10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mensaje = "Calculo Multivariable: 4.7 \nCreatividad: 5.0 \nElectromagnetismo: 4.8 \nEstrucutra de Datos: 4.8 \nMatemáticas Computacional: 4.8\nSeminario 2: 4.8";

                AlertDialog.Builder builder = new AlertDialog.Builder(CumplimientoCurricularActivity.this);
                builder.setTitle("Calificaciones Semestre 3");
                builder.setMessage(mensaje);

                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                // Crear y mostrar el diálogo
                AlertDialog dialog = builder.create();
                dialog.show();

                // Ajustar el tamaño de la ventana del diálogo
                WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
                layoutParams.copyFrom(dialog.getWindow().getAttributes());
                layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
                layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
                dialog.getWindow().setAttributes(layoutParams);
            }
        });

        Button button11 = findViewById(R.id.buttonD);
        button11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mensaje = "Base de Datos: 4.7 \nDesarrollo Multimedia: 5.0 \nEcuaciones Diferenciales: 4.8 \nEstadistica General: 4.8 \nInteligencia Artificial: 4.8\nTecnologias Moviles: 4.8";

                AlertDialog.Builder builder = new AlertDialog.Builder(CumplimientoCurricularActivity.this);
                builder.setTitle("Calificaciones Semestre 4");
                builder.setMessage(mensaje);

                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                // Crear y mostrar el diálogo
                AlertDialog dialog = builder.create();
                dialog.show();

                // Ajustar el tamaño de la ventana del diálogo
                WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
                layoutParams.copyFrom(dialog.getWindow().getAttributes());
                layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
                layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
                dialog.getWindow().setAttributes(layoutParams);
            }
        });

        Button button12 = findViewById(R.id.buttonE);
        button12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mensaje = "Arquitectura de Software: 4.7 \nBase de Datos 2: 5.0 \nElectiva Profundizacion: 4.8 \nInfraestructura Tecnológica: 4.8 \nIngenieria de Software: 4.8";

                AlertDialog.Builder builder = new AlertDialog.Builder(CumplimientoCurricularActivity.this);
                builder.setTitle("Calificaciones Semestre 5");
                builder.setMessage(mensaje);

                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                // Crear y mostrar el diálogo
                AlertDialog dialog = builder.create();
                dialog.show();

                // Ajustar el tamaño de la ventana del diálogo
                WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
                layoutParams.copyFrom(dialog.getWindow().getAttributes());
                layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
                layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
                dialog.getWindow().setAttributes(layoutParams);
            }
        });

        Button button13 = findViewById(R.id.buttonF);
        button13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mensaje = "Ciencia de Datos: 4.7 \nElectiva Profundización: 5.0 \nEtica de la Ingenieria: 4.8 \nIngenieria de Software 2: 4.8 \nInternet de las cosas: 4.8\nTeoria de Sistemas: 4.8";

                AlertDialog.Builder builder = new AlertDialog.Builder(CumplimientoCurricularActivity.this);
                builder.setTitle("Calificaciones Semestre 6");
                builder.setMessage(mensaje);

                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                // Crear y mostrar el diálogo
                AlertDialog dialog = builder.create();
                dialog.show();

                // Ajustar el tamaño de la ventana del diálogo
                WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
                layoutParams.copyFrom(dialog.getWindow().getAttributes());
                layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
                layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
                dialog.getWindow().setAttributes(layoutParams);
            }
        });

        Button button14 = findViewById(R.id.buttonG);
        button14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mensaje = "Ciberseguridad: 4.7 \nElectiva SocioHumanistica: 5.0 \nElectiva de Contexto: 4.8 \nElectiva Profundizacion: 4.8 \nInvestigacion de Operacionees: 4.8\nProyecto de Grado 1: 4.8";

                AlertDialog.Builder builder = new AlertDialog.Builder(CumplimientoCurricularActivity.this);
                builder.setTitle("Calificaciones Semestre 7");
                builder.setMessage(mensaje);

                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                // Crear y mostrar el diálogo
                AlertDialog dialog = builder.create();
                dialog.show();

                // Ajustar el tamaño de la ventana del diálogo
                WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
                layoutParams.copyFrom(dialog.getWindow().getAttributes());
                layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
                layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
                dialog.getWindow().setAttributes(layoutParams);
            }
        });

        Button button15 = findViewById(R.id.buttonH);
        button15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mensaje = "Dinamica de Sistemas: 4.7 \nElectiva SocioHumanistico: 5.0 \nElectiva Profundización 4.8 \nInvestigavion Operaciones 2: 4.8 \nProyecto de Grado 2: 4.8";

                AlertDialog.Builder builder = new AlertDialog.Builder(CumplimientoCurricularActivity.this);
                builder.setTitle("Calificaciones Semestre 8");
                builder.setMessage(mensaje);

                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                // Crear y mostrar el diálogo
                AlertDialog dialog = builder.create();
                dialog.show();

                // Ajustar el tamaño de la ventana del diálogo
                WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
                layoutParams.copyFrom(dialog.getWindow().getAttributes());
                layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
                layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
                dialog.getWindow().setAttributes(layoutParams);
            }
        });

        Button button16 = findViewById(R.id.buttonI);
        button16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mensaje = "Electiva de Contexto: 4.7 \nPractica en Ingenieria de Sistemas: 5.0";

                AlertDialog.Builder builder = new AlertDialog.Builder(CumplimientoCurricularActivity.this);
                builder.setTitle("Calificaciones Semestre 9");
                builder.setMessage(mensaje);

                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                // Crear y mostrar el diálogo
                AlertDialog dialog = builder.create();
                dialog.show();

                // Ajustar el tamaño de la ventana del diálogo
                WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
                layoutParams.copyFrom(dialog.getWindow().getAttributes());
                layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
                layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
                dialog.getWindow().setAttributes(layoutParams);
            }
        });

        Button button17 = findViewById(R.id.buttonJ);
        button17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mensaje = "Graduación: 5.0";

                AlertDialog.Builder builder = new AlertDialog.Builder(CumplimientoCurricularActivity.this);
                builder.setTitle("Calificaciones Semestre 10");
                builder.setMessage(mensaje);

                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                // Crear y mostrar el diálogo
                AlertDialog dialog = builder.create();
                dialog.show();

                // Ajustar el tamaño de la ventana del diálogo
                WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
                layoutParams.copyFrom(dialog.getWindow().getAttributes());
                layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
                layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
                dialog.getWindow().setAttributes(layoutParams);
            }
        });

        Button button18 = findViewById(R.id.buttonM);
        button18.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mensaje = "Nivel 1: Aprobado\nNivel 2: Aprobado\nNivel 3: Aprobado\nNivel 4: Aprobado\nNivel 5: Aprobado\nNivel 6: Aprobado\nNivel 7: Aprobado";

                AlertDialog.Builder builder = new AlertDialog.Builder(CumplimientoCurricularActivity.this);
                builder.setTitle("Proceso Curso de Inglés");
                builder.setMessage(mensaje);

                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                // Crear y mostrar el diálogo
                AlertDialog dialog = builder.create();
                dialog.show();

                // Ajustar el tamaño de la ventana del diálogo
                WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
                layoutParams.copyFrom(dialog.getWindow().getAttributes());
                layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
                layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
                dialog.getWindow().setAttributes(layoutParams);
            }
        });

        Button button19 = findViewById(R.id.buttonK);
        button19.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mensaje = "Taller Desarrollo: Aprobado \nTaller Deportes: Aprobado\nActividad Libre 1: Aprobado\nActividad Libre 2:Aprobado";

                AlertDialog.Builder builder = new AlertDialog.Builder(CumplimientoCurricularActivity.this);
                builder.setTitle("Proceso de Cursos de Bienestar");
                builder.setMessage(mensaje);

                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                // Crear y mostrar el diálogo
                AlertDialog dialog = builder.create();
                dialog.show();

                // Ajustar el tamaño de la ventana del diálogo
                WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
                layoutParams.copyFrom(dialog.getWindow().getAttributes());
                layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
                layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
                dialog.getWindow().setAttributes(layoutParams);
            }
        });

        Button button20 = findViewById(R.id.buttonL);
        button20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mensaje = "Curso Word: Aprobado \nCurso Excel: Aprobado\nCurso PowerPoint: Aprobado\nCurso Vida en Linea:Aprobado\nCurso Cultura Digital:Aprobado";

                AlertDialog.Builder builder = new AlertDialog.Builder(CumplimientoCurricularActivity.this);
                builder.setTitle("Proceso Curso de Informática");
                builder.setMessage(mensaje);

                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                // Crear y mostrar el diálogo
                AlertDialog dialog = builder.create();
                dialog.show();

                // Ajustar el tamaño de la ventana del diálogo
                WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
                layoutParams.copyFrom(dialog.getWindow().getAttributes());
                layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
                layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
                dialog.getWindow().setAttributes(layoutParams);
            }
        });
    }

    public void showPopupMenu(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Selecciona una opción");
        builder.setItems(R.array.options_array, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case 0: // Opción 1 seleccionada
                        openWebPage("https://unab.edu.co/");
                        break;
                    case 1: // Opción 2 seleccionada
                        openWebPage("https://unabvirtual.unab.edu.co/");
                        break;
                    case 2: // Opción 3 seleccionada
                        openWebPage("https://mail.google.com/");
                        break;
                    case 3: // Opción 4 seleccionada
                        openWebPage("https://tema.unab.edu.co/");
                        break;
                    case 4: // Opción 8 seleccionada
                        openWebPage("https://unab.instructure.com/login");
                        break;
                    case 5: // Opción 5 seleccionada
                        openWebPage("https://cosmos.unab.edu.co/");
                        break;
                    case 6: // Opción 6 seleccionada
                        openWebPage("https://unab.edu.co/sistema-de-bibliotecas-unab/");
                        break;
                    case 7: // Opción 7 seleccionada
                        openWebPage("https://bienestar.unab.edu.co/");
                        break;

                }
            }
        });
        builder.show();
    }

    private void openWebPage(String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);
    }

}

