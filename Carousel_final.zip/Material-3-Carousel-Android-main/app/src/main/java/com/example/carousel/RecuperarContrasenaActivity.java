package com.example.carousel;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RecuperarContrasenaActivity extends AppCompatActivity {

    private EditText usuarioEditText;
    private EditText emailEditText;
    private TextView recuperarContrasenaTextView;
    private Button enviarButton;
    private Button volverButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.rcontrasena_app);

        usuarioEditText = findViewById(R.id.c_id_usuario);
        emailEditText = findViewById(R.id.c_id_email);
        recuperarContrasenaTextView = findViewById(R.id.recuperar_contraseña);
        enviarButton = findViewById(R.id.boton_env_c);
        volverButton = findViewById(R.id.boton_vol_c);

        enviarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String usuario = usuarioEditText.getText().toString();
                String email = emailEditText.getText().toString();

                if (verificarDatos(usuario, email)) {
                    mostrarContrasena(usuario);
                } else {
                    Toast.makeText(RecuperarContrasenaActivity.this, "Datos incorrectos", Toast.LENGTH_SHORT).show();
                }
            }
        });

        volverButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RecuperarContrasenaActivity.this, LoginActivity.class);
                startActivity(intent);
                finish(); // Cierra la actividad actual (RecuperarContrasenaActivity)
            }
        });
    }

    private boolean verificarDatos(String usuario, String email) {
        SharedPreferences sharedPreferences = getSharedPreferences("Usuarios", MODE_PRIVATE);
        String usuarioRegistrado = sharedPreferences.getString("usuario", null);
        String emailRegistrado = sharedPreferences.getString("correo", null);

        return usuario.equals(usuarioRegistrado) && email.equals(emailRegistrado);
    }

    private void mostrarContrasena(String usuario) {
        SharedPreferences sharedPreferences = getSharedPreferences("Usuarios", MODE_PRIVATE);
        String contrasenaRegistrada = sharedPreferences.getString("contraseña", null);
        recuperarContrasenaTextView.setText("La contraseña para " + usuario + " es: " + contrasenaRegistrada);
        recuperarContrasenaTextView.setVisibility(View.VISIBLE);
    }
}