package com.example.carousel;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText usuarioEditText;
    private EditText contraseñaEditText;
    private Button entrarButton;
    private Button registrarseButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_app);

        usuarioEditText = findViewById(R.id.id_usuario);
        contraseñaEditText = findViewById(R.id.id_contraseña);
        entrarButton = findViewById(R.id.boton_entrar);
        registrarseButton = findViewById(R.id.boton_registrarse);

        entrarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String usuario = usuarioEditText.getText().toString();
                String contraseña = contraseñaEditText.getText().toString();

                if (verificarCredenciales(usuario, contraseña)) {
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish(); // Cierra la actividad actual (LoginActivity) para que no se mantenga en la pila de actividades
                } else {
                    Toast.makeText(LoginActivity.this, "Credenciales incorrectas", Toast.LENGTH_SHORT).show();
                }
            }
        });

        registrarseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, RegistroActivity.class);
                startActivity(intent);
            }
        });

        TextView olvidoContrasenaTextView = findViewById(R.id.olvido_contrasena);
        olvidoContrasenaTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, RecuperarContrasenaActivity.class);
                startActivity(intent);
            }
        });
    }

    private boolean verificarCredenciales(String usuario, String contraseña) {
        SharedPreferences sharedPreferences = getSharedPreferences("Usuarios", MODE_PRIVATE);
        String usuarioRegistrado = sharedPreferences.getString("usuario", null);
        String contraseñaRegistrada = sharedPreferences.getString("contraseña", null);

        return usuario.equals(usuarioRegistrado) && contraseña.equals(contraseñaRegistrada);
    }
}